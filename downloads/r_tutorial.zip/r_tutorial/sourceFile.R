#This is your first source file
#This is where you will type everything.
#All your notes should begin with the hash # symbol. Like these notes here. 
#Everything you want R to run must not have a # symbol.  Like our first calculator input.

#R can act as a calulator
2 + 2

2 + 7 #You can even put notes on the same line as something you want run in R.



